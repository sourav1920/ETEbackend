package com.example.EteBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EteBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EteBackendApplication.class, args);
	}

}
